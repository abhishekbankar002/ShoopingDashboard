from django.apps import AppConfig


class HelloworldConfig(AppConfig):
    name = 'helloworld'
